chrome.devtools.panels.create(
  "React Debugger",
  "icons/icon16.png",
  "panel.html"
);
